/* ============================================================
   DOWN EAST — DYNAMIC PRODUCT SEARCH  (de-search.js)
   Forgiving, chef-facing search over the full range.
   Handles: accents/case, trade shorthand (SK/ON, H&G, U/10, BLED),
   seafood synonyms (prawns↔shrimp, branzino↔loup de mer, calamari↔squid,
   uni↔sea urchin, striper↔striped bass…), free word order, plurals,
   and typos (fuzzy). Ranks best matches first.

   API:
     DeSearch.build(products)            // one-time index (lazy-safe)
     DeSearch.rank(list, query)          // -> ranked array of matches
     DeSearch.suggest(products, query)   // -> up to 5 "did you mean" species terms
   Each product uses fields: n (name), o (origin), c (category),
   plus optional s (on-floor), top (bestseller).
   ============================================================ */
(function(){

  /* words that carry no search signal — ignored in query & index matching */
  var STOP = {'de':1,'the':1,'of':1,'and':1,'a':1,'&':1,'with':1,'in':1,'no':1,'net':1,'gross':1,'weight':1};

  /* trade shorthand → the plain words a chef would type.
     keys are normalized tokens (slashes/dashes already turned to spaces, so 'sk/on' -> 'sk on') */
  var ABBREV = {
    'sk':['skin'], 'skon':['skin','on','skinon'], 'skoff':['skin','off','skinless'],
    'son':['skin','on'], 'soff':['skin','off','skinless'],
    'hon':['head','on'], 'hoff':['head','off','headless'], 'hg':['headed','gutted','h&g','dressed'],
    'pc':['portion','piece','portions'], 'prt':['portion','piece','portions'], 'port':['portion','portions'],
    'flt':['fillet','filet','fillets'], 'fillet':['filet','fillets'], 'fil':['fillet','filet'],
    'whl':['whole','round'], 'whole':['round'],
    'frz':['frozen','iqf'], 'frzn':['frozen'], 'iqf':['frozen'], 'frsh':['fresh'],
    'cs':['case'], 'ck':['cooked'], 'ckd':['cooked'], 'rw':['raw'],
    'ec':['east','coast','eastcoast'], 'wc':['west','coast','westcoast'],
    'lb':['pound','lbs'], 'kg':['kilo','kilogram'], 'oz':['ounce','ounces'], 'ct':['count'],
    'bled':['sushi','sashimi','sushigrade','sashimigrade'], 'sushi':['sashimi','sushigrade','raw'],
    'sashimi':['sushi','sashimigrade','raw'],
    'tt':['tubes','tentacles'], 'to':['tubes'],
    'dtrim':['trim','trimmed'], 'etrim':['trim','trimmed'], 'trim':['trimmed'],
    'jbo':['jumbo'], 'lg':['large'], 'med':['medium'], 'sm':['small'],
    'blk':['black'], 'frmd':['farmed'], 'wld':['wild'], 'dom':['domestic'],
    'u':['under'], 'hf':['half']
  };

  /* Synonym groups. If ANY trigger term (word or phrase) appears in a product's
     text, EVERY term in the group becomes searchable for that product.
     Terms are matched as normalized words (multi-word phrases split to words). */
  var SYN = [
    ['shrimp','prawn','prawns','gambas','gamba','crevette'],
    ['squid','calamari','calamare','calamares'],
    ['octopus','pulpo','poulpe'],
    ['branzino','bronzino','loup de mer','loup','european sea bass','mediterranean sea bass','spigola','bar','lubina'],
    ['dorade','dorado','daurade','gilthead','sea bream','bream','orata'],
    ['mahi','mahimahi','dorado','dolphinfish'],
    ['hamachi','yellowtail','japanese amberjack','buri'],
    ['hiramasa','yellowtail kingfish','kingfish','amberjack'],
    ['kanpachi','amberjack','greater amberjack'],
    ['fluke','summer flounder','flounder'],
    ['halibut','fletan'],
    ['turbot','turbo'],
    ['sole','dover sole','dover','lemon sole'],
    ['striped bass','striper','striped','rockfish','wild striped bass'],
    ['black sea bass','blackfish sea bass','sea bass black','black bass'],
    ['chilean sea bass','patagonian toothfish','toothfish','mero'],
    ['blackfish','tautog'],
    ['tilefish','tile','golden tilefish'],
    ['snapper','red snapper','american red snapper','huachinango','pargo'],
    ['grouper','mero'],
    ['cod','codfish','scrod','bacalao'],
    ['haddock','scrod'],
    ['pollock','pollack'],
    ['black cod','sablefish','sable','butterfish sable','gindara'],
    ['monkfish','anglerfish','lotte','anglerdfish'],
    ['skate','raie','ray'],
    ['swordfish','sword','espada'],
    ['tuna','ahi','maguro','bigeye','yellowfin','bluefin','toro'],
    ['salmon','saumon','sake','king salmon','coho','sockeye','atlantic salmon','ora king','faroe'],
    ['trout','steelhead','char','arctic char','omble'],
    ['branQ'], // placeholder guard (unused)
    ['sea urchin','uni','urchin','oursin'],
    ['caviar','roe','osetra','ossetra','kaluga','sevruga','beluga','sturgeon','paddlefish','tobiko','ikura','bottarga'],
    ['scallop','scallops','coquille','coquilles','pétoncle','hotate'],
    ['lobster','homard','langouste','spiny lobster'],
    ['langostino','langoustine','scampi','cigala'],
    ['crayfish','crawfish','ecrevisse','crawdad'],
    ['crab','crabmeat','jumbo lump','lump','peekytoe','dungeness','snow crab','king crab','soft shell','softshell'],
    ['oyster','oysters','huitre','huître'],
    ['clam','clams','littleneck','cherrystone','razor clam','manila','vongole'],
    ['mussel','mussels','moule','moules','bouchot'],
    ['conch','scungilli','whelk','periwinkle','winkle','sea snail','snail','escargot','turban'],
    ['branzini','branzino'],
    ['frog legs','frog','grenouille'],
    ['alligator','gator'],
    ['smoked salmon','lox','nova','gravlax','smoked'],
    ['anchovy','anchovies','boquerones'],
    ['sardine','sardines'],
    ['mackerel','saba','maquereau'],
    ['branQ2'], // guard
    ['eel','unagi','anago'],
    ['catfish','basa','swai','tra'],
    ['tilapia'],
    ['barramundi','asian sea bass'],
    ['perch','ocean perch','rockfish'],
    ['john dory','dory','saint pierre','st pierre','zeus'],
    ['porgy','scup'],
    ['bluefish','tailor'],
    ['pompano','permit'],
    ['wahoo','ono'],
    ['cobia','lemonfish','ling'],
    ['branQ3']
  ];

  /* usage / prep concepts -> the product signals that satisfy them */
  var CONCEPT = {
    'sushi grade':['sushi','sashimi','bled','tuna','hamachi','fluke','salmon','hiramasa','uni'],
    'sushigrade':['sushi','sashimi','bled'],
    'raw bar':['oyster','clam','uni','shrimp','littleneck','crab'],
    'rawbar':['oyster','clam','uni','shrimp'],
    'skinless':['skin off','sk off'],
    'skin on':['sk on','skin on'],
    'day boat':['dayboat','day boat'],
    'shellfish':['oyster','clam','mussel','scallop','shrimp','lobster','crab','squid','octopus'],
    'crudo':['sushi','sashimi','bled','fluke','tuna','hamachi'],
    'whitefish':['cod','halibut','sole','flounder','fluke','tilapia','basa','catfish','haddock','snapper']
  };

  /* build a lookup: word -> array of all synonym-group words that should light up */
  var SYNMAP = {};   // trigger word -> Set of expansion words
  var SYNPHRASE = []; // {phrase, words[]} for multi-word triggers
  SYN.forEach(function(group){
    var words = {};
    group.forEach(function(term){
      term.split(/\s+/).forEach(function(w){ if(w && !STOP[w]) words[w]=1; });
    });
    var wl = Object.keys(words);
    group.forEach(function(term){
      if(term.indexOf(' ')>=0){ SYNPHRASE.push({p:norm(term), w:wl}); }
      else {
        if(!SYNMAP[term]) SYNMAP[term]={};
        wl.forEach(function(w){ SYNMAP[term][w]=1; });
      }
    });
  });

  function stripAccents(s){
    return s.normalize ? s.normalize('NFD').replace(/[̀-ͯ]/g,'') : s;
  }
  function norm(s){
    return stripAccents(String(s||'').toLowerCase())
      .replace(/[\/\-_,.()"'+&]/g,' ')
      .replace(/[^a-z0-9 ]/g,' ')
      .replace(/\s+/g,' ').trim();
  }

  function addTokens(set, arr){ for(var i=0;i<arr.length;i++){ if(arr[i]&&!STOP[arr[i]]) set[arr[i]]=1; } }

  /* Build the search index on each product (idempotent) */
  function build(products){
    for(var i=0;i<products.length;i++){
      var p=products[i];
      if(p.__t) continue;
      var nameN = norm(p.n);
      var blob  = norm(p.n+' '+(p.o||'')+' '+(p.c||''));
      var toks={};
      var base=blob.split(' ');
      addTokens(toks, base);
      // also add glued slash-forms so 'sk/on'→'skon', 'u/10'→'u10', '10/20'→'1020'
      var raw=String(p.n||'').toLowerCase();
      (raw.match(/[a-z0-9]+\/[a-z0-9]+/g)||[]).forEach(function(m){ toks[m.replace(/\//g,'')]=1; });
      // abbreviation expansion
      Object.keys(toks).slice().forEach(function(t){ if(ABBREV[t]) addTokens(toks, ABBREV[t]); });
      // synonym expansion (single-word triggers)
      Object.keys(toks).slice().forEach(function(t){ if(SYNMAP[t]) addTokens(toks, Object.keys(SYNMAP[t])); });
      // synonym expansion (multi-word phrase triggers)
      for(var s=0;s<SYNPHRASE.length;s++){ if(blob.indexOf(SYNPHRASE[s].p)>=0) addTokens(toks, SYNPHRASE[s].w); }
      // concept expansion
      Object.keys(CONCEPT).forEach(function(ck){
        var sig=CONCEPT[ck]; for(var z=0;z<sig.length;z++){ if(blob.indexOf(sig[z])>=0){ addTokens(toks, norm(ck).split(' ')); break; } }
      });
      p.__n = nameN;
      p.__b = Object.keys(toks).join(' ');
      p.__t = Object.keys(toks);
    }
  }

  /* bounded Levenshtein — returns distance, bails past max */
  function lev(a,b,max){
    var la=a.length, lb=b.length;
    if(Math.abs(la-lb)>max) return max+1;
    var prev=[], cur=[], i,j;
    for(j=0;j<=lb;j++) prev[j]=j;
    for(i=1;i<=la;i++){
      cur[0]=i; var best=cur[0];
      for(j=1;j<=lb;j++){
        var cost=a.charCodeAt(i-1)===b.charCodeAt(j-1)?0:1;
        cur[j]=Math.min(prev[j]+1, cur[j-1]+1, prev[j-1]+cost);
        if(cur[j]<best) best=cur[j];
      }
      if(best>max) return max+1;
      var t=prev; prev=cur; cur=t;
    }
    return prev[lb];
  }

  function maxDist(len){ return len>=8?2 : len>=4?1 : 0; }

  /* score one product against the already-normalized query tokens.
     Soft-AND: we don't hard-drop when one descriptive word misses (so
     "day boat scallops" still finds scallops), but products that match
     MORE of the query — and match it more strongly — rank higher. */
  function scoreProduct(p, qtokens, qphrase){
    var total=0, matched=0, strong=0;
    for(var i=0;i<qtokens.length;i++){
      var qt=qtokens[i], best=0, md=maxDist(qt.length);
      if(p.__t.indexOf(qt)>=0){ best=4; }
      else {
        var toks=p.__t;
        for(var j=0;j<toks.length;j++){
          var t=toks[j];
          if(best<3 && t.length>qt.length && t.lastIndexOf(qt,0)===0){ best=3; }      // prefix
          else if(best<2.5 && qt.length>=3 && t.indexOf(qt)>=0){ best=2.5; }           // substring in token
          if(best>=3) break;
        }
        if(best===0 && p.__b.indexOf(qt)>=0){ best=2; }                                // substring in blob
        if(best===0 && md>0){                                                          // fuzzy / typo
          for(var k=0;k<toks.length;k++){ var dd=lev(qt,toks[k],md); if(dd<=md){ best=(dd<=1?2:1); break; } }
        }
      }
      if(best>0){ matched++; total+=best; if(best>=2) strong++; }
    }
    if(matched===0 || strong===0) return null;                  // needs at least one solid hit
    var all = matched===qtokens.length;
    if(all) total+=4;                                           // reward full-query matches
    if(qphrase){
      if(p.__n===qphrase) total+=8;
      else if(p.__n.lastIndexOf(qphrase,0)===0) total+=5;
      else if(p.__n.indexOf(qphrase)>=0) total+=3;
      else if(p.__b.indexOf(qphrase)>=0) total+=1;
    }
    if(p.top) total+=1.5;
    if(p.s)   total+=1.0;
    return {score:total, matched:matched};
  }

  /* Rank a candidate list against a query. Returns a NEW array (ranked). */
  function rank(list, query){
    var q=norm(query);
    if(!q) return list.slice();
    build(list);
    var qtokens=q.split(' ').filter(function(w){ return w && !STOP[w]; });
    if(!qtokens.length) return list.slice();
    var scored=[];
    for(var i=0;i<list.length;i++){
      var r=scoreProduct(list[i], qtokens, q);
      if(r) scored.push([r.matched, r.score, i, list[i]]);
    }
    scored.sort(function(a,b){
      if(b[0]!==a[0]) return b[0]-a[0];                         // more query words matched first
      if(b[1]!==a[1]) return b[1]-a[1];                         // then higher relevance score
      if(!!b[3].top!==!!a[3].top) return (b[3].top?1:0)-(a[3].top?1:0);
      return a[2]-b[2];
    });
    return scored.map(function(x){ return x[3]; });
  }

  /* Suggest species terms when a search comes up short */
  function suggest(products, query){
    var q=norm(query); if(q.length<2) return [];
    var pool={};
    SYN.forEach(function(g){ g.forEach(function(t){ if(t.indexOf('branQ')<0) pool[t]=1; }); });
    var terms=Object.keys(pool), out=[];
    for(var i=0;i<terms.length;i++){
      var t=terms[i];
      if(t.lastIndexOf(q,0)===0 || t.indexOf(q)>=0){ out.push(t); }
      else if(q.length>=4){ var parts=t.split(' '); for(var j=0;j<parts.length;j++){ if(lev(q,parts[j],2)<=2){ out.push(t); break; } } }
      if(out.length>=6) break;
    }
    return out.slice(0,5);
  }

  window.DeSearch = { build:build, rank:rank, suggest:suggest, norm:norm };
})();
