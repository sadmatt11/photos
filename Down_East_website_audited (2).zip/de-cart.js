/* ============================================================
   DOWN EAST — SHARED ORDER CART  (de-cart.js)
   One cart, shared across every page via localStorage.
   Add from any page, check out from any page.
   Usage on a page:
     <script src="de-cart.js" defer></script>
     <button onclick="DECart.add('62136069-01-601','Faroe Salmon HF','Farmed Faroe Islands · by the LB')">+ Add</button>
   Listen for changes to repaint your own button states:
     document.addEventListener('decart:change', fn)
   ============================================================ */
(function(){
  var VER   = 'v4';
  var KEY   = 'de_cart';
  var ACCT  = 'de_acct';
  var LAST  = 'de_last';
  // Contact details come from de-contact.js when present (one place to edit),
  // with the current values as fallbacks if that file isn't loaded.
  var PHONE   = (window.DE_CONTACT && DE_CONTACT.textTel)     || '8443474685';
  var PHONE_H = (window.DE_CONTACT && DE_CONTACT.textDisplay) || '(844) 347-4685';
  var EMAIL   = (window.DE_CONTACT && DE_CONTACT.email)       || 'orders@downeastseafoodny.com';

  /* ---------- state ---------- */
  var items = {};           // { sku: {name, sub, spec} }
  function load(){
    try{
      var raw = JSON.parse(localStorage.getItem(KEY)||'null');
      if(raw && raw.v===VER && raw.items){ items = raw.items; }
      else { items = {}; localStorage.removeItem(KEY); }
    }catch(e){ items = {}; }
  }
  function persist(){
    try{ localStorage.setItem(KEY, JSON.stringify({v:VER, items:items, ts:Date.now()})); }catch(e){}
  }
  function emit(){
    document.dispatchEvent(new CustomEvent('decart:change',{detail:{count:count()}}));
    paintCount();
    if(drawerOpen) render();
  }

  /* ---------- public API ---------- */
  function has(sku){ return !!items[sku]; }
  function count(){ return Object.keys(items).length; }
  // Pull a default unit of measure out of the "…by the LB" sub-line when the
  // caller doesn't pass one explicitly.
  function parseUnit(sub){
    var m=/by the\s+([a-z0-9\/&.\-]+)/i.exec(sub||'');
    return m ? m[1].toUpperCase() : '';
  }
  function add(sku, name, sub, unit){
    if(!sku) return;
    if(items[sku]){ delete items[sku]; }          // toggle off if already in
    else { items[sku] = {name:name||sku, sub:sub||'', unit:(unit||parseUnit(sub)), qty:''}; }
    persist(); emit();
    return has(sku);
  }
  function addOnly(sku, name, sub, unit){          // never toggles off
    if(!sku) return;
    if(!items[sku]) items[sku] = {name:name||sku, sub:sub||'', unit:(unit||parseUnit(sub)), qty:''};
    persist(); emit(); open();
  }
  function remove(sku){ delete items[sku]; persist(); emit(); }
  function setQty(sku,val){ if(items[sku]){ items[sku].qty = val; persist(); } }
  function setUnit(sku,val){ if(items[sku]){ items[sku].unit = val; persist(); } }
  function clearAll(){ items = {}; persist(); emit(); }

  /* ---------- account memory ---------- */
  function acctLoad(){ try{ return JSON.parse(localStorage.getItem(ACCT)||'null'); }catch(e){ return null; } }
  function acctSave(r,c){ try{ localStorage.setItem(ACCT, JSON.stringify({r:r,c:c})); }catch(e){} }

  /* ---------- reorder last ---------- */
  function lastLoad(){ try{ return JSON.parse(localStorage.getItem(LAST)||'null'); }catch(e){ return null; } }
  function lastSave(){ try{ localStorage.setItem(LAST, JSON.stringify({items:items, ts:Date.now()})); }catch(e){} }
  function reorderLast(){
    var l = lastLoad();
    if(!l || !l.items || !Object.keys(l.items).length){ toast('No previous order found on this device.'); return; }
    Object.keys(l.items).forEach(function(k){ if(!items[k]){ var it=l.items[k]; items[k] = {name:it.name, sub:it.sub, unit:it.unit||'', qty:it.qty||''}; } });
    persist(); emit(); open();
  }

  /* ---------- order reference ---------- */
  function makeRef(){ return 'DE-'+Math.floor(1000+(Date.now()%9000)); }

  function esc(s){ return (s||'').replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }

  /* ---------- send ---------- */
  function send(method){
    var rEl=document.getElementById('dc-rest'), cEl=document.getElementById('dc-contact');
    var restaurant=(rEl&&rEl.value||'').trim();
    var contact=(cEl&&cEl.value||'').trim();
    var delivery=(document.getElementById('dc-deliv')||{}).value||'';
    var note=(document.getElementById('dc-note')||{}).value||'';
    delivery=delivery.trim(); note=note.trim();

    if(!restaurant){ flash(rEl); return; }
    if(!contact){ flash(cEl); return; }

    var keys=Object.keys(items);
    if(!keys.length){ toast('Add some items first.'); return; }

    var lines=[], missing=[];
    keys.forEach(function(k){
      var qEl=document.getElementById('dc-qty-'+cssId(k));
      var uEl=document.getElementById('dc-unit-'+cssId(k));
      var qty=(qEl&&qEl.value||items[k].qty||'').trim();
      var unit=(uEl&&uEl.value||items[k].unit||'').trim();
      items[k].qty=qty; items[k].unit=unit;
      if(!qty){ missing.push(k); if(qEl){ qEl.classList.add('dc-err'); } }
      else { lines.push('  • '+items[k].name+' ['+k+']: '+qty+(unit?' '+unit:'')); }
    });
    if(missing.length){ toast('Enter a quantity for each item.'); return; }

    var ref=makeRef();
    var msg='Down East order — '+restaurant+'\nRef: '+ref+'\nContact: '+contact;
    if(delivery) msg+='\nDelivery: '+delivery;
    msg+='\n\n'+lines.join('\n');
    if(note) msg+='\n\nNote: '+note;

    acctSave(restaurant,contact);
    lastSave();

    if(method==='email'){
      window.location='mailto:'+EMAIL+'?subject='+encodeURIComponent('Order '+ref+' — '+restaurant)+'&body='+encodeURIComponent(msg);
    }else{
      var sep=/iPhone|iPad|iPod/i.test(navigator.userAgent)?'&':'?';
      window.location='sms:'+PHONE+sep+'body='+encodeURIComponent(msg);
    }
    // clear the order first (keep remembered account for next time), then show confirmation
    items={}; persist(); paintCount();
    document.dispatchEvent(new CustomEvent('decart:change',{detail:{count:0}}));
    confirmView(ref, method);
  }

  function cssId(k){ return String(k).replace(/[^a-zA-Z0-9_-]/g,'_'); }
  function flash(el){ if(!el) return; el.classList.add('dc-err'); el.focus(); setTimeout(function(){el.classList.remove('dc-err');},2200); }

  /* ---------- rendering ---------- */
  var drawerOpen=false;
  function paintCount(){
    var n=count();
    document.querySelectorAll('[data-dc-count]').forEach(function(el){ el.textContent=n; });
    document.querySelectorAll('.dc-fab').forEach(function(el){ el.classList.toggle('has', n>0); });
  }
  function acctPrefill(){
    var a=acctLoad(); if(!a) return;
    var r=document.getElementById('dc-rest'); if(r&&!r.value) r.value=a.r||'';
    var c=document.getElementById('dc-contact'); if(c&&!c.value) c.value=a.c||'';
  }
  function render(){
    var body=document.getElementById('dc-body'); if(!body) return;
    var keys=Object.keys(items);
    if(!keys.length){
      body.innerHTML='<div class="dc-empty">No items yet.<br>Add anything from the floor, the dock report, or the full range.</div>';
    }else{
      body.innerHTML=keys.map(function(k){
        var it=items[k];
        return '<div class="dc-item">'
          +'<div class="dc-item-top"><div class="dc-item-nm">'+esc(it.name)+'</div>'
          +'<button class="dc-x" title="Remove" onclick="DECart.remove(\''+jsq(k)+'\')">✕</button></div>'
          +(it.sub?'<div class="dc-item-sub">'+esc(it.sub)+'</div>':'')
          +'<div class="dc-sku">Item #'+esc(k)+'</div>'
          +'<div class="dc-spec-row">'
          +'<input class="dc-qty" id="dc-qty-'+cssId(k)+'" inputmode="decimal" value="'+esc(it.qty||'')+'" '
          +'placeholder="Qty *" aria-label="Quantity (required)" '
          +'oninput="DECart.setQty(\''+jsq(k)+'\',this.value);this.classList.remove(\'dc-err\')">'
          +'<input class="dc-unit" id="dc-unit-'+cssId(k)+'" value="'+esc(it.unit||'')+'" '
          +'placeholder="unit" aria-label="Unit of measure" '
          +'oninput="DECart.setUnit(\''+jsq(k)+'\',this.value)"></div></div>';
      }).join('');
    }
    acctPrefill();
  }
  function jsq(s){ return String(s).replace(/'/g,"\\'"); }

  function confirmView(ref, method){
    var body=document.getElementById('dc-body'); if(!body) return;
    var how=method==='email'?'email':'text';
    body.innerHTML='<div class="dc-confirm">'
      +'<div class="dc-check">✓</div>'
      +'<div class="dc-chd">Order '+esc(ref)+' ready to send</div>'
      +'<div class="dc-csub">Your '+how+' is opening now — tap send and we\'ll confirm availability, cuts &amp; pricing right back. '
      +'Mention <strong>'+esc(ref)+'</strong> if you call.</div>'
      +'<button class="dc-again" onclick="DECart.render()">Start another order</button></div>';
    open(true);
  }

  function open(skipRender){ var o=document.getElementById('dc-ov'), d=document.getElementById('dc-drawer'); if(o)o.classList.add('on'); if(d)d.classList.add('on'); drawerOpen=true; if(!skipRender) render(); }
  function close(){ var o=document.getElementById('dc-ov'), d=document.getElementById('dc-drawer'); if(o)o.classList.remove('on'); if(d)d.classList.remove('on'); drawerOpen=false; }

  /* ---------- toast ---------- */
  var toastT;
  function toast(msg){
    var t=document.getElementById('dc-toast');
    if(!t){ t=document.createElement('div'); t.id='dc-toast'; t.className='dc-toast'; document.body.appendChild(t); }
    t.textContent=msg; t.classList.add('on');
    clearTimeout(toastT); toastT=setTimeout(function(){ t.classList.remove('on'); },2600);
  }

  /* ---------- inject UI + styles ---------- */
  var CSS = ''
  +'.dc-fab{position:fixed;right:18px;bottom:18px;z-index:900;display:flex;align-items:center;gap:9px;'
  +'font-family:"Barlow Condensed",sans-serif;font-weight:800;font-size:14px;letter-spacing:.12em;text-transform:uppercase;'
  +'color:#060d1a;background:#C9A84C;border:0;border-radius:30px;padding:13px 20px;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.45);transition:.15s}'
  +'.dc-fab:hover{background:#dbbb5e;transform:translateY(-2px)}'
  +'.dc-fab .dc-cnt{background:#060d1a;color:#C9A84C;min-width:22px;height:22px;border-radius:11px;display:inline-flex;align-items:center;justify-content:center;font-family:"IBM Plex Mono",monospace;font-size:11px;font-weight:600;padding:0 6px}'
  +'.dc-ov{position:fixed;inset:0;background:rgba(4,7,13,.66);opacity:0;pointer-events:none;transition:.2s;z-index:950}'
  +'.dc-ov.on{opacity:1;pointer-events:auto}'
  +'.dc-drawer{position:fixed;top:0;right:0;height:100%;width:400px;max-width:92vw;background:#0b1825;border-left:1px solid rgba(237,229,208,.14);'
  +'z-index:960;transform:translateX(102%);transition:transform .24s cubic-bezier(.4,0,.1,1);display:flex;flex-direction:column;box-shadow:-20px 0 50px rgba(0,0,0,.5)}'
  +'.dc-drawer.on{transform:translateX(0)}'
  +'.dc-hd{display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid rgba(237,229,208,.1);flex-shrink:0}'
  +'.dc-hd-t{font-family:"Barlow Condensed",sans-serif;font-weight:900;font-size:18px;text-transform:uppercase;letter-spacing:.05em;color:#EDE5D0}'
  +'.dc-hd-s{font-size:11px;color:#5e7080;margin-top:1px}'
  +'.dc-close{background:none;border:0;color:#7a8fa0;font-size:13px;font-family:"Barlow Condensed",sans-serif;font-weight:700;text-transform:uppercase;letter-spacing:.06em;cursor:pointer}'
  +'.dc-close:hover{color:#EDE5D0}'
  +'.dc-body{flex:1;overflow-y:auto;padding:14px 20px}'
  +'.dc-empty{text-align:center;color:#5e7080;font-size:13px;line-height:1.6;padding:40px 10px}'
  +'.dc-item{padding:12px 0;border-bottom:1px solid rgba(237,229,208,.07)}'
  +'.dc-item-top{display:flex;justify-content:space-between;align-items:flex-start;gap:8px}'
  +'.dc-item-nm{font-family:"Barlow Condensed",sans-serif;font-weight:700;font-size:15px;text-transform:uppercase;color:#EDE5D0;line-height:1.15}'
  +'.dc-item-sub{font-size:11.5px;color:#7a8fa0;margin-top:2px}'
  +'.dc-sku{font-family:"IBM Plex Mono",monospace;font-size:10px;color:#5e7080;margin-top:3px;letter-spacing:.02em}'
  +'.dc-x{background:none;border:0;color:#5e7080;cursor:pointer;font-size:13px;flex-shrink:0}.dc-x:hover{color:#C41E1E}'
  +'.dc-spec-row{display:flex;gap:8px;margin-top:8px}'
  +'.dc-qty{width:90px;flex:0 0 auto;background:#060d1a;border:1px solid rgba(237,229,208,.14);border-radius:5px;color:#EDE5D0;font-family:inherit;font-size:12.5px;padding:8px 10px}'
  +'.dc-unit{flex:1;min-width:0;background:#060d1a;border:1px solid rgba(237,229,208,.14);border-radius:5px;color:#EDE5D0;font-family:inherit;font-size:12.5px;padding:8px 10px;text-transform:uppercase;letter-spacing:.03em}'
  +'.dc-qty::placeholder,.dc-unit::placeholder{color:rgba(237,229,208,.28)}'
  +'.dc-qty:focus,.dc-unit:focus{outline:none;border-color:#C9A84C}'
  +'.dc-qty.dc-err,.dc-fld.dc-err{border-color:#C41E1E!important}'
  +'.dc-fields{padding:12px 20px;border-top:1px solid rgba(237,229,208,.1);flex-shrink:0}'
  +'.dc-frow{margin-bottom:8px}'
  +'.dc-lbl{font-family:"Barlow Condensed",sans-serif;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#7a8fa0;margin-bottom:3px}'
  +'.dc-lbl b{color:#C41E1E}'
  +'.dc-fld{width:100%;background:#060d1a;border:1px solid rgba(237,229,208,.14);border-radius:5px;color:#EDE5D0;font-family:inherit;font-size:13px;padding:9px 11px}'
  +'.dc-fld::placeholder{color:rgba(237,229,208,.28)}.dc-fld:focus{outline:none;border-color:#C9A84C}'
  +'.dc-acts{padding:12px 20px 18px;border-top:1px solid rgba(237,229,208,.1);flex-shrink:0}'
  +'.dc-send-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px}'
  +'.dc-send{padding:12px 6px;border:0;border-radius:5px;cursor:pointer;font-family:"Barlow Condensed",sans-serif;font-size:13px;font-weight:900;text-transform:uppercase;letter-spacing:.05em}'
  +'.dc-send.sms{background:#C9A84C;color:#060d1a}.dc-send.email{background:#10203a;border:1px solid #C9A84C;color:#C9A84C}'
  +'.dc-send:hover{opacity:.9}'
  +'.dc-row2{display:flex;gap:14px;justify-content:center;margin-top:4px}'
  +'.dc-mini{background:none;border:0;color:#7a8fa0;font-size:11.5px;font-family:"Barlow Condensed",sans-serif;font-weight:700;text-transform:uppercase;letter-spacing:.05em;cursor:pointer}'
  +'.dc-mini:hover{color:#C9A84C}'
  +'.dc-confirm{text-align:center;padding:34px 18px}'
  +'.dc-check{width:52px;height:52px;margin:0 auto 14px;border-radius:50%;background:#C9A84C;color:#060d1a;font-size:28px;font-weight:900;display:flex;align-items:center;justify-content:center}'
  +'.dc-chd{font-family:"Barlow Condensed",sans-serif;font-size:20px;font-weight:900;text-transform:uppercase;letter-spacing:.04em;color:#EDE5D0}'
  +'.dc-csub{font-size:12.5px;color:rgba(237,229,208,.72);line-height:1.55;margin-top:8px}.dc-csub strong{color:#C9A84C}'
  +'.dc-again{margin-top:16px;background:none;border:1px solid rgba(237,229,208,.22);color:#EDE5D0;font-family:"Barlow Condensed",sans-serif;font-weight:700;text-transform:uppercase;letter-spacing:.06em;font-size:12px;padding:9px 16px;border-radius:5px;cursor:pointer}'
  +'.dc-toast{position:fixed;left:50%;bottom:84px;transform:translateX(-50%) translateY(14px);z-index:980;background:#10203a;border:1px solid #C9A84C;color:#EDE5D0;font-size:13px;padding:11px 18px;border-radius:8px;max-width:88vw;text-align:center;opacity:0;pointer-events:none;transition:.2s;box-shadow:0 10px 30px rgba(0,0,0,.4)}'
  +'.dc-toast.on{opacity:1;transform:translateX(-50%) translateY(0)}'
  +'@media(max-width:520px){.dc-fab{right:12px;bottom:12px;padding:12px 16px}}';

  var DRAWER = ''
  +'<div class="dc-ov" id="dc-ov" onclick="DECart.close()"></div>'
  +'<aside class="dc-drawer" id="dc-drawer" aria-label="Your order">'
  +'  <div class="dc-hd"><div><div class="dc-hd-t">Your Order</div><div class="dc-hd-s">Text or email it to us — we confirm availability &amp; pricing</div></div>'
  +'    <button class="dc-close" onclick="DECart.close()">✕ Close</button></div>'
  +'  <div class="dc-body" id="dc-body"></div>'
  +'  <div class="dc-fields">'
  +'    <div class="dc-frow"><div class="dc-lbl">Restaurant <b>*</b></div><input class="dc-fld" id="dc-rest" placeholder="Restaurant name" autocomplete="organization"></div>'
  +'    <div class="dc-frow"><div class="dc-lbl">Your Name <b>*</b></div><input class="dc-fld" id="dc-contact" placeholder="Chef or buyer" autocomplete="name"></div>'
  +'    <div class="dc-frow"><div class="dc-lbl">Delivery Date</div><input class="dc-fld" id="dc-deliv" placeholder="e.g. Thursday, or ASAP"></div>'
  +'    <div class="dc-frow"><div class="dc-lbl">Notes</div><input class="dc-fld" id="dc-note" placeholder="Special cuts, anything else…"></div>'
  +'  </div>'
  +'  <div class="dc-acts">'
  +'    <div class="dc-send-grid">'
  +'      <button class="dc-send sms" onclick="DECart.send(\'sms\')">Text Order</button>'
  +'      <button class="dc-send email" onclick="DECart.send(\'email\')">Email Order</button>'
  +'    </div>'
  +'    <div class="dc-row2"><button class="dc-mini" onclick="DECart.reorderLast()">↻ Reorder last</button>'
  +'      <button class="dc-mini" onclick="DECart.clearAll()">Clear order</button></div>'
  +'  </div>'
  +'</aside>';

  function injectFabIfNeeded(){
    // Only auto-add a floating button if the page doesn't already have its own cart trigger
    if(document.querySelector('[data-dc-fab-skip]')) return;
    if(document.querySelector('.dc-fab')) return;
    var fab=document.createElement('button');
    fab.className='dc-fab';
    fab.setAttribute('onclick','DECart.open()');
    fab.innerHTML='Your Order <span class="dc-cnt" data-dc-count>0</span>';
    document.body.appendChild(fab);
  }

  function boot(){
    load();
    var style=document.createElement('style'); style.textContent=CSS; document.head.appendChild(style);
    var wrap=document.createElement('div'); wrap.innerHTML=DRAWER;
    while(wrap.firstChild){ document.body.appendChild(wrap.firstChild); }
    injectFabIfNeeded();
    paintCount();
    render();
  }

  /* expose */
  window.DECart = {
    add:add, addOnly:addOnly, remove:remove, has:has, count:count,
    setQty:setQty, setUnit:setUnit, clearAll:clearAll, reorderLast:reorderLast,
    open:open, close:close, send:send, render:render, paintCount:paintCount
  };

  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', boot); }
  else { boot(); }
})();
