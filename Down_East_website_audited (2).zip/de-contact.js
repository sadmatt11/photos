/* ============================================================
   DOWN EAST — SHARED CONTACT INFO  (de-contact.js)
   -----------------------------------------------------------
   ONE place to change the phone numbers, the text/order line,
   the email and the address for the WHOLE site.

   To update: edit the values in the "CANONICAL" block below,
   save, and re-upload this one file. Every page that loads
   de-contact.js updates automatically — footers, order strips,
   "Call / Text / Email" rows, and the cart's send target.

   Include on every page (before de-cart.js):
     <script src="de-contact.js" defer></script>

   How it works: pages still ship the current numbers as plain
   text/links. On load this file finds those known values and
   rewrites them to the canonical values below. So you only ever
   edit them here — the old values stay in the LEGACY lists as
   the "find" targets and never need touching.
   ============================================================ */
(function(){

  var DE_CONTACT = {
    /* ---------- CANONICAL — edit these ---------- */
    callDisplay : '(347) 590-8007',                 // "Call" line, as shown
    callTel     : '3475908007',                     // "Call" line, digits only (tel:)
    textDisplay : '(844) 347-4685',                 // "Text"/order line, as shown
    textTel     : '8443474685',                     // "Text" line, digits only (sms:)
    email       : 'orders@downeastseafoodny.com',
    address     : '311 Manida Street, Bronx, NY 10474',
    website     : 'downeastseafoodny.com',

    /* ---------- LEGACY — the values currently baked into the pages ----------
       These are the strings this script searches for and replaces with the
       canonical values above. Add the OLD value here whenever you change a
       canonical one, so existing pages keep getting rewritten correctly. */
    legacyCallDisplays : ['(347) 590-8007','347-590-8007','347.590.8007'],
    legacyCallTels     : ['3475908007'],
    legacyTextDisplays : ['(844) 347-4685','844-347-4685'],
    legacyTextTels     : ['8443474685'],
    legacyEmails       : ['orders@downeastseafoodny.com']
  };
  window.DE_CONTACT = DE_CONTACT;

  function digits(s){ return String(s||'').replace(/\D/g,''); }

  // Replace known literal strings inside a single text node (safe: exact matches only)
  function rewriteText(txt){
    var out = txt;
    DE_CONTACT.legacyCallDisplays.forEach(function(v){ if(v!==DE_CONTACT.callDisplay) out = out.split(v).join(DE_CONTACT.callDisplay); });
    DE_CONTACT.legacyTextDisplays.forEach(function(v){ if(v!==DE_CONTACT.textDisplay) out = out.split(v).join(DE_CONTACT.textDisplay); });
    DE_CONTACT.legacyEmails.forEach(function(v){ if(v!==DE_CONTACT.email) out = out.split(v).join(DE_CONTACT.email); });
    return out;
  }

  function sweepText(root){
    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode:function(n){
        var p = n.parentNode;
        if(!p) return NodeFilter.FILTER_REJECT;
        var tag = p.nodeName;
        if(tag==='SCRIPT'||tag==='STYLE'||tag==='TEXTAREA') return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    var n, changed=[];
    while((n=walker.nextNode())){
      var v = rewriteText(n.nodeValue);
      if(v!==n.nodeValue) changed.push([n,v]);
    }
    changed.forEach(function(pair){ pair[0].nodeValue = pair[1]; });
  }

  function apply(){
    // 1) tel: links -> canonical call number (only rewrite ones that were the old number)
    document.querySelectorAll('a[href^="tel:"]').forEach(function(a){
      if(DE_CONTACT.legacyCallTels.indexOf(digits(a.getAttribute('href')))>=0)
        a.setAttribute('href','tel:'+DE_CONTACT.callTel);
    });
    // 2) sms: links -> canonical text number, preserving any ?body= payload
    document.querySelectorAll('a[href^="sms:"]').forEach(function(a){
      var href = a.getAttribute('href')||'';
      var num  = digits(href.replace(/[?&].*$/,''));
      if(DE_CONTACT.legacyTextTels.indexOf(num)>=0){
        var payload = href.replace(/^sms:[^?&]*/,'');
        a.setAttribute('href','sms:'+DE_CONTACT.textTel+payload);
      }
    });
    // 3) mailto: links -> canonical email, preserving subject/body
    document.querySelectorAll('a[href^="mailto:"]').forEach(function(a){
      var href = a.getAttribute('href')||'';
      var addr = href.replace(/^mailto:/,'').replace(/[?&].*$/,'');
      if(DE_CONTACT.legacyEmails.indexOf(addr)>=0){
        var payload = href.replace(/^mailto:[^?&]*/,'');
        a.setAttribute('href','mailto:'+DE_CONTACT.email+payload);
      }
    });
    // 4) Visible text (footers, "Call · (347)…", address lines, etc.)
    if(document.body) sweepText(document.body);
    // 5) Optional explicit placeholders: <span data-de="call|text|email|address">
    document.querySelectorAll('[data-de]').forEach(function(el){
      var k = el.getAttribute('data-de');
      if(k==='call')    el.textContent = DE_CONTACT.callDisplay;
      if(k==='text')    el.textContent = DE_CONTACT.textDisplay;
      if(k==='email')   el.textContent = DE_CONTACT.email;
      if(k==='address') el.textContent = DE_CONTACT.address;
      if(k==='website') el.textContent = DE_CONTACT.website;
    });
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', apply);
  else apply();
})();
