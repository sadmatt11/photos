# Down East — Content Editor (Decap CMS) setup

This lets your team edit content at **`yoursite.com/admin`** — no code, no
downloading/re-uploading files. Saving publishes to the site automatically.

What's already wired in this repo:
- `admin/` — the editor (login + forms).
- `content/*.json` — the data files the site reads and the CMS edits.
- `uploads/` — where uploaded PDFs and photos are stored.
- **Catch of the Week** reads `content/catch-of-the-week.json`.
- **Market Brief** shows a "Download the Market Book (PDF)" button once a PDF
  is uploaded (from `content/market-book.json`).

---

## One-time Netlify setup (~10 minutes)

1. **Create the site on Netlify** from the GitHub repo (`sadmatt11/photos`):
   Netlify → *Add new site → Import an existing project → GitHub → pick the repo*.
   Build command: *none*. Publish directory: `/` (the repo root).

2. **Turn on logins** (Netlify Identity + Git Gateway):
   - Site → *Integrations / Identity* → **Enable Identity**.
   - Identity → *Registration* → set to **Invite only**.
   - Identity → *Services → Git Gateway* → **Enable Git Gateway**.

3. **Let the login box work on the site.** Add these two lines to the
   `<head>` of `index.html` (the site's front door) so invite links complete:
   ```html
   <script src="https://identity.netlify.com/v1/netlify-identity-widget.js"></script>
   <script>
     if (window.netlifyIdentity) {
       netlifyIdentity.on("init", u => { if (!u) netlifyIdentity.on("login", () => { document.location.href = "/admin/"; }); });
     }
   </script>
   ```
   (Say the word and I'll add this for you.)

4. **Invite your team:** Identity → *Invite users* → enter their emails. They
   click the emailed link, set a password, and they're in.

5. **Edit:** go to **`yoursite.com/admin`**, log in, pick *Catch of the Week*
   or *Market Book*, make changes, and **Publish**. The site updates in ~30s.

---

## Adding the rest of the reports

Each report follows the same 3-step recipe (I can do these next):
1. Pull the page's content into a `content/<page>.json` file.
2. Point the page at it (one `fetch(...)` line, like Catch of the Week).
3. Add a matching block under **Reports & Updates** in `admin/config.yml`.

Already converted: **Catch of the Week**, **Dock Report**, **Market Book (PDF)**.
Still to convert: Midweek, Weekend, Market Brief body, Oyster Programme.
Products & availability are better handled by a Google Sheet (separate, staff-
friendly for ~1,400 items) — ask and I'll wire it.

Note: the Dock Report's per-item price fields are deliberately **not** editable
in the CMS, so the site can never publish selling prices.

---

## If Netlify Identity isn't available on your plan

Netlify is phasing Identity out for some new sites. If you don't see it, use
the **GitHub backend** instead — replace the `backend:` block in
`admin/config.yml` with:
```yaml
backend:
  name: github
  repo: sadmatt11/photos
  branch: main
```
…then add GitHub as an OAuth provider in Netlify (*Site settings → Access &
security → OAuth → Install provider → GitHub*). Editors log in with GitHub.
