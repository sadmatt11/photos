/* ============================================================
   DOWN EAST — SHARED SITE NAV  (de-nav.js)
   One consistent, sticky top navigation on every page:
   brand · clear destinations · a search box that routes into
   the full catalog · one cart button in the same place.
   Include on every page:  <script src="de-nav.js" defer></script>
   Pair with de-cart.js (cart) and de-search.js (search).
   ============================================================ */
(function(){
  var LINKS = [
    {h:'dock-report.html',    t:'Dock Report'},
    {h:'reports.html',        t:'Updates'},
    {h:'product-library.html',t:'The Full Range'},
    {h:'pre-order.html',      t:'Pre-Order'},
    {h:'oyster-programme.html',t:'Oysters'},
    {h:'seasonality.html',    t:'Seasonality'},
    {h:'offshore-conditions.html',t:'Conditions'}
  ];
  var MORE = [
    {h:'market-brief.html',      t:'Market Brief'},
    {h:'catch-of-the-week.html', t:'Catch of the Week'},
    {h:'oyster-solutions.html',  t:'Oyster Solutions'},
    {h:'kitchen-guide.html',     t:'Kitchen Guide'},
    {h:'chefs-access-card.html', t:'Chef Access · QR Card'}
  ];
  var here = (location.pathname.split('/').pop()||'home.html').toLowerCase();
  if(here==='index.html'||here==='') here='home.html';

  var CSS = ''
  +'.denav{position:sticky;top:0;z-index:1000;background:#06080f;border-bottom:1px solid rgba(237,229,208,.10);'
  +'display:flex;align-items:center;gap:14px;height:56px;padding:0 18px;font-family:"Barlow Condensed",sans-serif}'
  +'.denav a{text-decoration:none}'
  +'.denav-brand{font-weight:900;font-size:17px;letter-spacing:.10em;text-transform:uppercase;color:#EDE5D0;white-space:nowrap;flex-shrink:0}'
  +'.denav-brand em{color:#C9A84C;font-style:normal}'
  +'.denav-links{display:flex;gap:2px;flex:1;overflow-x:auto;scrollbar-width:none;min-width:0}'
  +'.denav-links::-webkit-scrollbar{display:none}'
  +'.denav-links a{font-weight:600;font-size:13px;letter-spacing:.07em;text-transform:uppercase;color:rgba(237,229,208,.72);'
  +'padding:8px 10px;border-radius:6px;white-space:nowrap;transition:.15s}'
  +'.denav-links a:hover{color:#EDE5D0;background:#10203a}'
  +'.denav-links a.on{color:#C9A84C}'
  +'.denav-search{display:flex;align-items:center;gap:7px;background:#0e1b2b;border:1px solid rgba(237,229,208,.16);'
  +'border-radius:20px;padding:7px 12px;flex-shrink:0;transition:.15s;width:172px}'
  +'.denav-search:focus-within{border-color:#C9A84C;width:230px}'
  +'.denav-search .mg{color:#7a8fa0;font-size:14px}'
  +'.denav-search input{background:none;border:0;outline:none;color:#EDE5D0;font-family:"Barlow",sans-serif;font-size:13.5px;width:100%}'
  +'.denav-search input::placeholder{color:rgba(237,229,208,.4)}'
  +'.denav-cart{display:flex;align-items:center;gap:8px;flex-shrink:0;background:#C9A84C;color:#060d1a;border:0;'
  +'border-radius:8px;padding:9px 15px;font-family:"Barlow Condensed",sans-serif;font-weight:800;font-size:13.5px;'
  +'letter-spacing:.10em;text-transform:uppercase;cursor:pointer;transition:.15s}'
  +'.denav-cart:hover{background:#dbbb5e}'
  +'.denav-cart svg{width:16px;height:16px}'
  +'.denav-cart .n{background:#060d1a;color:#C9A84C;min-width:21px;height:21px;border-radius:11px;display:inline-flex;'
  +'align-items:center;justify-content:center;font-family:"IBM Plex Mono",monospace;font-size:11px;font-weight:600;padding:0 6px}'
  +'.denav-more{position:relative;flex-shrink:0}'
  +'.denav-more-btn{background:none;border:0;font-family:"Barlow Condensed",sans-serif;font-weight:600;font-size:13px;letter-spacing:.07em;text-transform:uppercase;color:rgba(237,229,208,.72);padding:8px 10px;border-radius:6px;cursor:pointer;white-space:nowrap}'
  +'.denav-more-btn:hover,.denav-more-btn.on{color:#C9A84C}'
  +'.denav-drop{position:absolute;top:calc(100% + 8px);right:0;background:#0b1220;border:1px solid rgba(237,229,208,.16);border-radius:9px;padding:6px;min-width:214px;display:none;flex-direction:column;box-shadow:0 14px 34px rgba(0,0,0,.55);z-index:1001}'
  +'.denav-drop.open{display:flex}'
  +'.denav-drop a{font-family:"Barlow Condensed",sans-serif;font-weight:600;font-size:13.5px;letter-spacing:.05em;text-transform:uppercase;color:rgba(237,229,208,.8);padding:10px 12px;border-radius:6px;white-space:nowrap}'
  +'.denav-drop a:hover{color:#C9A84C;background:#10203a}'
  +'.denav-drop a.on{color:#C9A84C}'
  +'.denav-burger{display:none}'
  +'@media(max-width:860px){'
  +'  .denav{gap:9px;padding:0 12px}'
  +'  .denav-search{width:150px}.denav-search:focus-within{width:170px}'
  +'  .denav-cart .lbl{display:none}.denav-cart{padding:9px 12px}'
  +'}'
  +'@media(max-width:560px){'
  +'  .denav-search{display:none}'
  +'  .denav-links{gap:0}'
  +'  .denav-links a{font-size:12.5px;padding:8px 9px}'
  +'}';

  function navHTML(){
    var updates = {'reports.html':1,'midweek-update.html':1,'weekend-update.html':1};
    var links = LINKS.map(function(l){
      var active = (l.h.toLowerCase()===here) || (l.h==='reports.html' && updates[here]);
      return '<a href="'+l.h+'"'+(active?' class="on"':'')+'>'+l.t+'</a>';
    }).join('');
    var moreOn = false;
    var moreLinks = MORE.map(function(l){
      var a = (l.h.toLowerCase()===here); if(a) moreOn=true;
      return '<a href="'+l.h+'"'+(a?' class="on"':'')+'>'+l.t+'</a>';
    }).join('');
    return ''
    +'<a class="denav-brand" id="deBrand" href="home.html">DOWN <em>EAST</em></a>'
    +'<nav class="denav-links">'+links+'</nav>'
    +'<div class="denav-more"><button class="denav-more-btn'+(moreOn?' on':'')+'" id="deMore" aria-haspopup="true" aria-expanded="false">More ▾</button>'
    +'<div class="denav-drop" id="deDrop">'+moreLinks+'</div></div>'
    +'<div class="denav-search"><span class="mg">⌕</span>'
    +'<input id="deNavQ" type="search" placeholder="Search all products…" '
    +'autocomplete="off" aria-label="Search all products"></div>';
  }

  function routeSearch(q){
    q=(q||'').trim(); if(!q) return;
    if(here==='product-library.html'){
      var box=document.getElementById('q');
      if(box){ box.value=q; box.focus();
        if(typeof activeCat!=='undefined'){ try{activeCat='All';}catch(e){} }
        if(typeof onSearch==='function') onSearch(); else if(typeof renderShop==='function') renderShop();
        return;
      }
    }
    window.location.href='product-library.html?q='+encodeURIComponent(q);
  }

  function boot(){
    if(document.querySelector('.denav')) return;
    var style=document.createElement('style'); style.textContent=CSS; document.head.appendChild(style);
    var bar=document.createElement('div'); bar.className='denav'; bar.innerHTML=navHTML();
    document.body.insertBefore(bar, document.body.firstChild);
    var q=document.getElementById('deNavQ');
    if(q){
      q.addEventListener('keydown',function(e){ if(e.key==='Enter'){ e.preventDefault(); routeSearch(q.value); } });
    }
    var mb=document.getElementById('deMore'), dd=document.getElementById('deDrop');
    if(mb && dd){
      mb.addEventListener('click',function(e){ e.stopPropagation(); var open=dd.classList.toggle('open'); mb.setAttribute('aria-expanded', open?'true':'false'); });
      document.addEventListener('click',function(){ dd.classList.remove('open'); mb.setAttribute('aria-expanded','false'); });
      dd.addEventListener('click',function(e){ e.stopPropagation(); });
    }
    // Admin pages hide their own masthead (which carried the triple-click logo)
    // in favour of this shared nav, so restore that gesture on the shared brand:
    // triple-click the logo opens the page's admin editor; a single click still
    // routes home (briefly deferred to let a triple-click register).
    var brand=document.getElementById('deBrand');
    if(brand && typeof window.tripleClickAdmin==='function'){
      var _n=0,_tm=null;
      brand.addEventListener('click',function(e){
        e.preventDefault();
        _n++;
        try{ window.tripleClickAdmin(); }catch(err){}   // page counts internally; opens on its 3rd rapid click
        if(_tm){ clearTimeout(_tm); _tm=null; }
        if(_n>=3){ _n=0; return; }                       // admin opened — don't also navigate home
        _tm=setTimeout(function(){ _n=0; window.location.href='home.html'; },500);
      });
    }
    if(window.DECart && DECart.paintCount) DECart.paintCount();
  }

  if(document.readyState==='loading'){ document.addEventListener('DOMContentLoaded', boot); }
  else { boot(); }
})();
